import React from 'react';
import Tarjeta from "./Tarjeta";

function Fila(props){
    return (
        <div className="fila">
            {console.log("El prop de cardshow en la fila: " + props.cardShow)}
            <Tarjeta image={props.datos[0]} backImage={props.backImage} cardClick={props.cardClick} name={props.nameList[0]} id={props.idList[0]} whoShows={props.cardShow}/>
            <Tarjeta image={props.datos[1]} backImage={props.backImage} cardClick={props.cardClick} name={props.nameList[1]} id={props.idList[1]} whoShows={props.cardShow}/>
            <Tarjeta image={props.datos[2]} backImage={props.backImage} cardClick={props.cardClick} name={props.nameList[2]} id={props.idList[2]} whoShows={props.cardShow}/>
            <Tarjeta image={props.datos[3]} backImage={props.backImage} cardClick={props.cardClick} name={props.nameList[3]} id={props.idList[3]} whoShows={props.cardShow}/>
            <Tarjeta image={props.datos[4]} backImage={props.backImage} cardClick={props.cardClick} name={props.nameList[4]} id={props.idList[4]} whoShows={props.cardShow}/>
            <Tarjeta image={props.datos[5]} backImage={props.backImage} cardClick={props.cardClick} name={props.nameList[5]} id={props.idList[5]} whoShows={props.cardShow}/>
        </div>
    )
}

export default Fila;