import React from 'react';

class Tarjeta extends React.Component {
    state = {
        flipped: true,
        img: '',
        existFlag: false,
    }

    shouldFlip = () =>{
        if(this.props.whoShows)
            for(let i=0; i <this.props.whoShows.length; i++){
                if(this.props.whoShows[i] === this.props.id){
                    this.setState({existFlag: true})
                }
            }
        if(this.state.existFlag)
            this.setState({flipped: true})
        else
            this.setState({flipped: false})
    }

    render() {
        return (
            <img
                src={this.state.flipped ? this.props.backImage : this.props.image}
                className="tarjeta"
                id={this.props.name}
                alt=''
                onClick={() => {
                    this.shouldFlip()
                    this.props.cardClick(this.props.id, this.props.name)
                    console.log("El prop cardshow en la tarjeta : " + this.props.whoShows)
                }
            }/>
        )
    }
}

export default Tarjeta;

/*
onClick={this.props.cardClick(this.props.name)}

 */