import logo from './logo.svg';
import './App.css';
import axios from 'axios';
import React from 'react';
import {BrowserRouter, Route, Switch} from 'react-router-dom';
import Container from "@material-ui/core/Container";
//import Button from '@material-ui/core/Button';
import Grid from '@material-ui/core/Button';
import Fila from "./Fila";

class App extends React.Component {
    state = {
        datos: [],
        datos1: [],
        datos2: [],
        datos3: [],
        nameList1: '',
        nameList2: '',
        nameList3: '',
        idList1: '',
        idList2: '',
        idList3: '',
        backImage: '',
        firstCardId: '',
        secondCardId: '',
        firstCardName: '',
        secondCardName: '',
        cardId: [],
        cardName: [],
        cardShow: []
    }

    componentDidMount() {
        const url = 'https://machineglearningdatasets.s3.eu-central-1.amazonaws.com/cards.json';
        axios.get(url).then((response) => {
                this.setState({datos: response.data});
                let randomNumber;
                let randomArray = [];
                let nameArray = ['bowser', 'diddy', 'luigi', 'mario', 'peach', 'rosalina', 'toad', 'wario', 'yoshi']
                let usedArray = [0, 0, 0, 0, 0, 0, 0, 0, 0];
                for (let i = 0; i < 18; i++) {
                    randomNumber = Math.floor(Math.random() * 9);
                    if (usedArray[randomNumber] !== 2) {
                        usedArray[randomNumber] += 1;
                        randomArray.push(nameArray[randomNumber]);
                    } else {
                        i--;
                    }
                }
                let datos1 = []
                let datos2 = []
                let datos3 = []
                let nameList1 = []
                let nameList2 = []
                let nameList3 = []
                let idList1 = []
                let idList2 = []
                let idList3 = []
                for (let i = 0; i < 18; i++) {
                    if (i < 6) {
                        datos1.push(this.state.datos[randomArray[i]])
                        nameList1.push(randomArray[i])
                        idList1.push(i)
                    } else if (i < 12 && i >= 6) {
                        datos2.push(this.state.datos[randomArray[i]])
                        nameList2.push(randomArray[i])
                        idList2.push(i)
                    } else if (i < 18 && i >= 12) {
                        datos3.push(this.state.datos[randomArray[i]])
                        nameList3.push(randomArray[i])
                        idList3.push(i)
                    }
                }
                this.setState({
                    datos1: datos1,
                    datos2: datos2,
                    datos3: datos3,
                    nameList1: nameList1,
                    nameList2: nameList2,
                    nameList3: nameList3,
                    idList1: idList1,
                    idList2: idList2,
                    idList3: idList3,
                })
                this.setState({
                    backImage: this.state.datos.back
                })
            }
        );
    }

    cardClick = (cardId, cardName) => {
        let cardsId = this.state.cardId
        let cardsName = this.state.cardName
        let cardShow = this.state.cardShow
        console.log("Card clicked: " + cardName + ' ID: ' + cardId);
        if (this.state.firstCardId === '') {
            console.log("Esa carta es la primera")
            cardsId[0] = cardId;
            cardsName[0] = cardName
            cardShow.push(cardId)
            this.setState({
                firstCardId: cardId,
                firstCardName: cardName,
                cardShow: cardShow
            })
        } else if (cardId !== cardsId[0]) {
            console.log("Esa carta es la segunda")
            cardsId[1] = cardId;
            cardsName[1] = cardName
            cardShow.push(cardId)
            this.setState({
                secondCardId: cardId,
                secondCardName: cardName,
                cardShow: cardShow
            })
            this.cardCheck();
        }
        this.setState({
            cardsId: cardsId
        })
    }

    cardCheck = () => {
        let cardShow = this.state.cardShow
        if (this.state.firstCardName === this.state.secondCardName)
            console.log("They are the same");
        else {
            console.log("They are different");
            cardShow.pop()
            cardShow.pop()
        }
        this.sleep(1000).then(() => {
            this.setState({
                firstCardId: '',
                secondCardId: '',
                firstCardName: '',
                secondCardName: '',
                cardId: [],
                cardName: [],
                cardShow: cardShow
            })
        });
    }

    sleep = (time) => {
        return new Promise((resolve) => setTimeout(resolve, time));
    }

    render() {
        return (
            <div className="App">
                <div className="grid">
                    <div>
                        {/*AQUI ESTA EL BUG: en this.state.cardShow guardo los ids de las cartas que deben mostrarse en pantalla, no obstante si vemos el console log de cada fila vemos que ese prop siempre es undefined aunque cambie el cardShow de el state de la app*/}
                        {/*Notese que el cardshow puede estar vacio hasta que encuentres una pareja de cartas, funciona conteniendo el id de las cartas que hay que mostrar, hace pop de las ultimas dos cartas si no eran iguales*/}
                        {console.log("El cardshow en la App : "+this.state.cardShow)}
                        <Fila datos={this.state.datos1} backImage={this.state.backImage} cardClick={this.cardClick} idList={this.state.idList1} nameList={this.state.nameList1} whoShows={this.state.cardShow}/>
                    </div>
                    <div>
                        <Fila datos={this.state.datos2} backImage={this.state.backImage} cardClick={this.cardClick} idList={this.state.idList2} nameList={this.state.nameList1} whoShows={this.state.cardShow}/>
                    </div>
                    <div>
                        <Fila datos={this.state.datos3} backImage={this.state.backImage} cardClick={this.cardClick} idList={this.state.idList3} nameList={this.state.nameList1} whoShows={this.state.cardShow}/>
                    </div>
                </div>
            </div>

        );
    }
}

export default App;

/*
<BrowserRouter>
    <Switch>
        <Route path="/" exact>
            <Formulario busquedaSubmit={this.busqueda}/>
        </Route>
        <Route path="/artist">
            <Artist datos={this.state.datos} nombre={this.state.nombre}/>
        </Route>
        <Route path="/release-group">
            <ReleaseGroup datos={this.state.datos} nombre={this.state.nombre}/>
        </Route>
    </Switch>
</BrowserRouter>
 */